try:
    n1 = int(input("Ingrese un número: "))
except:
    print("No ingresaste un número")
