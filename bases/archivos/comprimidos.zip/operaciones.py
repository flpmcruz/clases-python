import math

print(1 + 3)
print(1 - 3)
print(1 * 3)
print(1 / 3)
print(1 // 3)  # division entera
print(1 % 3)  # resto de la division
print(1 ** 3)  # potencia

print(round(1.5))  # redondeo
print(abs(-1.5))  # valor absoluto

print(math.ceil(1.5))  # redondeo hacia arriba
print(math.floor(1.5))  # redondeo hacia abajo
print(math.sqrt(9))  # raiz cuadrada
print(math.isnan(9))  # es un numero?
print(math.pi)  # constante pi
print(math.pow(2, 3))  # potencia
