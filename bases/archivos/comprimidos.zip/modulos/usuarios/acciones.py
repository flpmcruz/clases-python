def cantar():
    print('Estoy cantando')


def bailar():
    print('Estoy bailando')
