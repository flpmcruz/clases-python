# conversion

# int() -> convierte a entero
# float() -> convierte a flotante
# str() -> convierte a cadena
# bool() -> convierte a booleano
