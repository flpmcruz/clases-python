def init(db, api, **_):
    print(f"init de {__name__} con {db} y {api}")
