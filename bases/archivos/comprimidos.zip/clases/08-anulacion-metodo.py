

class Ave:
    def vuela(self):
        print("vuela ave")


class Pato(Ave):
    def vuela(self):
        print("vuela pato")


pato = Pato()
pato.vuela()
