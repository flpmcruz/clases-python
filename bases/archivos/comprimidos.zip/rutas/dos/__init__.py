def init(graphql, **_):
    print(f"init de {__name__} con {graphql}")
